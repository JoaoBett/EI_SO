/*
João Bettencourt - 2221463
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <string.h>

#include "debug.h"
#include "memory.h"
#include "args.h"

#define INVALID_ENCRYPTED_NUMBER -1

int main(int argc, char *argv[]){
struct gengetopt_args_info args;
    int number = 4;
    if(cmdline_parser(argc,argv,&args) != 0)
    {
        return EXIT_FAILURE;
    };
    //Verifica se o numero inserido pelo usuario é entre 1 e 3 e se não for é dado um erro
    if(args.encryptednumber_given){
        if(args.encryptednumber_arg < 1 || args.encryptednumber_arg > 3){
            ERROR(INVALID_ENCRYPTED_NUMBER,"Invalid number:");
        }
        number = args.encryptednumber_arg;
    }

    printf("Ciphered Text: %s\n", args.encryptedtext_arg);
    printf("Deciphered text:\n");
    //Verifica o numero inserido pelo usuario
    if(number == 1 || number == 4){
        for(size_t i=0; i < strlen(args.encryptedtext_arg);i++){
            switch (args.encryptedtext_arg[i]){
                //Minusculas
                case 'a': args.encryptedtext_arg[i] = 'z'; break;
                case 'b': args.encryptedtext_arg[i] = 'a'; break;
                case 'c': args.encryptedtext_arg[i] = 'b'; break;
                case 'd': args.encryptedtext_arg[i] = 'c'; break;
                case 'e': args.encryptedtext_arg[i] = 'd'; break;
                case 'f': args.encryptedtext_arg[i] = 'e'; break;
                case 'g': args.encryptedtext_arg[i] = 'f'; break;
                case 'h': args.encryptedtext_arg[i] = 'g'; break;
                case 'i': args.encryptedtext_arg[i] = 'h'; break;
                case 'j': args.encryptedtext_arg[i] = 'i'; break;                
                case 'k': args.encryptedtext_arg[i] = 'j'; break;
                case 'l': args.encryptedtext_arg[i] = 'k'; break;
                case 'm': args.encryptedtext_arg[i] = 'l'; break;
                case 'n': args.encryptedtext_arg[i] = 'm'; break;
                case 'o': args.encryptedtext_arg[i] = 'n'; break;
                case 'p': args.encryptedtext_arg[i] = 'o'; break;
                case 'q': args.encryptedtext_arg[i] = 'p'; break;
                case 'r': args.encryptedtext_arg[i] = 'q'; break;
                case 's': args.encryptedtext_arg[i] = 'r'; break;
                case 't': args.encryptedtext_arg[i] = 's'; break;
                case 'u': args.encryptedtext_arg[i] = 't'; break;
                case 'v': args.encryptedtext_arg[i] = 'u'; break;
                case 'x': args.encryptedtext_arg[i] = 'v'; break;
                case 'w': args.encryptedtext_arg[i] = 'w'; break;
                case 'y': args.encryptedtext_arg[i] = 'x'; break;
                case 'z': args.encryptedtext_arg[i] = 'y'; break;                
                //Maiusculas
                case 'A': args.encryptedtext_arg[i] = 'Z'; break;
                case 'B': args.encryptedtext_arg[i] = 'A'; break;
                case 'C': args.encryptedtext_arg[i] = 'B'; break;
                case 'D': args.encryptedtext_arg[i] = 'C'; break;
                case 'E': args.encryptedtext_arg[i] = 'D'; break;
                case 'F': args.encryptedtext_arg[i] = 'E'; break;
                case 'G': args.encryptedtext_arg[i] = 'F'; break;
                case 'H': args.encryptedtext_arg[i] = 'G'; break;
                case 'I': args.encryptedtext_arg[i] = 'H'; break;
                case 'J': args.encryptedtext_arg[i] = 'I'; break;                
                case 'K': args.encryptedtext_arg[i] = 'J'; break;
                case 'L': args.encryptedtext_arg[i] = 'K'; break;
                case 'M': args.encryptedtext_arg[i] = 'L'; break;
                case 'N': args.encryptedtext_arg[i] = 'M'; break;
                case 'O': args.encryptedtext_arg[i] = 'N'; break;
                case 'P': args.encryptedtext_arg[i] = 'O'; break;
                case 'Q': args.encryptedtext_arg[i] = 'P'; break;
                case 'R': args.encryptedtext_arg[i] = 'Q'; break;
                case 'S': args.encryptedtext_arg[i] = 'R'; break;
                case 'T': args.encryptedtext_arg[i] = 'S'; break;
                case 'U': args.encryptedtext_arg[i] = 'T'; break;
                case 'V': args.encryptedtext_arg[i] = 'U'; break;
                case 'X': args.encryptedtext_arg[i] = 'V'; break;
                case 'W': args.encryptedtext_arg[i] = 'W'; break;
                case 'Y': args.encryptedtext_arg[i] = 'X'; break;
                case 'Z': args.encryptedtext_arg[i] = 'Y'; break;
            }
        }
        printf("N = 1 : %s\n",args.encryptedtext_arg);
    }
    if(number == 2 || number == 4){
        for(size_t i=0; i < strlen(args.encryptedtext_arg);i++){
            switch (args.encryptedtext_arg[i]){
                case 'a': args.encryptedtext_arg[i] = 'y'; break;
                case 'b': args.encryptedtext_arg[i] = 'z'; break;
                case 'c': args.encryptedtext_arg[i] = 'a'; break;
                case 'd': args.encryptedtext_arg[i] = 'b'; break;
                case 'e': args.encryptedtext_arg[i] = 'c'; break;
                case 'f': args.encryptedtext_arg[i] = 'd'; break;
                case 'g': args.encryptedtext_arg[i] = 'e'; break;
                case 'h': args.encryptedtext_arg[i] = 'f'; break;
                case 'i': args.encryptedtext_arg[i] = 'g'; break;
                case 'j': args.encryptedtext_arg[i] = 'h'; break;                
                case 'k': args.encryptedtext_arg[i] = 'i'; break;
                case 'l': args.encryptedtext_arg[i] = 'j'; break;
                case 'm': args.encryptedtext_arg[i] = 'k'; break;
                case 'n': args.encryptedtext_arg[i] = 'l'; break;
                case 'o': args.encryptedtext_arg[i] = 'm'; break;
                case 'p': args.encryptedtext_arg[i] = 'n'; break;
                case 'q': args.encryptedtext_arg[i] = 'o'; break;
                case 'r': args.encryptedtext_arg[i] = 'p'; break;
                case 's': args.encryptedtext_arg[i] = 'q'; break;
                case 't': args.encryptedtext_arg[i] = 'r'; break;
                case 'u': args.encryptedtext_arg[i] = 's'; break;
                case 'v': args.encryptedtext_arg[i] = 't'; break;
                case 'x': args.encryptedtext_arg[i] = 'u'; break;
                case 'w': args.encryptedtext_arg[i] = 'v'; break;
                case 'y': args.encryptedtext_arg[i] = 'w'; break;
                case 'z': args.encryptedtext_arg[i] = 'x'; break;                
                //Maiusculass
                case 'A': args.encryptedtext_arg[i] = 'Y'; break;
                case 'B': args.encryptedtext_arg[i] = 'Z'; break;
                case 'C': args.encryptedtext_arg[i] = 'A'; break;
                case 'D': args.encryptedtext_arg[i] = 'B'; break;
                case 'E': args.encryptedtext_arg[i] = 'C'; break;
                case 'F': args.encryptedtext_arg[i] = 'D'; break;
                case 'G': args.encryptedtext_arg[i] = 'E'; break;
                case 'H': args.encryptedtext_arg[i] = 'F'; break;
                case 'I': args.encryptedtext_arg[i] = 'G'; break;
                case 'J': args.encryptedtext_arg[i] = 'H'; break;                
                case 'K': args.encryptedtext_arg[i] = 'I'; break;
                case 'L': args.encryptedtext_arg[i] = 'J'; break;
                case 'M': args.encryptedtext_arg[i] = 'K'; break;
                case 'N': args.encryptedtext_arg[i] = 'L'; break;
                case 'O': args.encryptedtext_arg[i] = 'M'; break;
                case 'P': args.encryptedtext_arg[i] = 'N'; break;
                case 'Q': args.encryptedtext_arg[i] = 'O'; break;
                case 'R': args.encryptedtext_arg[i] = 'P'; break;
                case 'S': args.encryptedtext_arg[i] = 'Q'; break;
                case 'T': args.encryptedtext_arg[i] = 'R'; break;
                case 'U': args.encryptedtext_arg[i] = 'S'; break;
                case 'V': args.encryptedtext_arg[i] = 'T'; break;
                case 'X': args.encryptedtext_arg[i] = 'U'; break;
                case 'W': args.encryptedtext_arg[i] = 'V'; break;
                case 'Y': args.encryptedtext_arg[i] = 'W'; break;
                case 'Z': args.encryptedtext_arg[i] = 'X'; break;
            }
        }
        printf("N = 2 : %s\n",args.encryptedtext_arg);
    }

    if(number == 3 || number == 4){
        for(size_t i=0; i < strlen(args.encryptedtext_arg);i++){
            switch (args.encryptedtext_arg[i]){
                case 'a': args.encryptedtext_arg[i] = 'x'; break;
                case 'b': args.encryptedtext_arg[i] = 'y'; break;
                case 'c': args.encryptedtext_arg[i] = 'z'; break;
                case 'd': args.encryptedtext_arg[i] = 'a'; break;
                case 'e': args.encryptedtext_arg[i] = 'b'; break;
                case 'f': args.encryptedtext_arg[i] = 'c'; break;
                case 'g': args.encryptedtext_arg[i] = 'd'; break;
                case 'h': args.encryptedtext_arg[i] = 'e'; break;
                case 'i': args.encryptedtext_arg[i] = 'f'; break;
                case 'j': args.encryptedtext_arg[i] = 'g'; break;                
                case 'k': args.encryptedtext_arg[i] = 'h'; break;
                case 'l': args.encryptedtext_arg[i] = 'i'; break;
                case 'm': args.encryptedtext_arg[i] = 'j'; break;
                case 'n': args.encryptedtext_arg[i] = 'k'; break;
                case 'o': args.encryptedtext_arg[i] = 'l'; break;
                case 'p': args.encryptedtext_arg[i] = 'm'; break;
                case 'q': args.encryptedtext_arg[i] = 'n'; break;
                case 'r': args.encryptedtext_arg[i] = 'o'; break;
                case 's': args.encryptedtext_arg[i] = 'p'; break;
                case 't': args.encryptedtext_arg[i] = 'q'; break;
                case 'u': args.encryptedtext_arg[i] = 'r'; break;
                case 'v': args.encryptedtext_arg[i] = 's'; break;
                case 'x': args.encryptedtext_arg[i] = 't'; break;
                case 'w': args.encryptedtext_arg[i] = 'u'; break;
                case 'y': args.encryptedtext_arg[i] = 'v'; break;
                case 'z': args.encryptedtext_arg[i] = 'w'; break;
                //Maiusculas
                case 'A': args.encryptedtext_arg[i] = 'X'; break;
                case 'B': args.encryptedtext_arg[i] = 'Y'; break;
                case 'C': args.encryptedtext_arg[i] = 'Z'; break;
                case 'D': args.encryptedtext_arg[i] = 'A'; break;
                case 'E': args.encryptedtext_arg[i] = 'B'; break;
                case 'F': args.encryptedtext_arg[i] = 'C'; break;
                case 'G': args.encryptedtext_arg[i] = 'D'; break;
                case 'H': args.encryptedtext_arg[i] = 'E'; break;
                case 'I': args.encryptedtext_arg[i] = 'F'; break;
                case 'J': args.encryptedtext_arg[i] = 'G'; break;                
                case 'K': args.encryptedtext_arg[i] = 'H'; break;
                case 'L': args.encryptedtext_arg[i] = 'I'; break;
                case 'M': args.encryptedtext_arg[i] = 'J'; break;
                case 'N': args.encryptedtext_arg[i] = 'K'; break;
                case 'O': args.encryptedtext_arg[i] = 'L'; break;
                case 'P': args.encryptedtext_arg[i] = 'M'; break;
                case 'Q': args.encryptedtext_arg[i] = 'N'; break;
                case 'R': args.encryptedtext_arg[i] = 'O'; break;
                case 'S': args.encryptedtext_arg[i] = 'P'; break;
                case 'T': args.encryptedtext_arg[i] = 'Q'; break;
                case 'U': args.encryptedtext_arg[i] = 'R'; break;
                case 'V': args.encryptedtext_arg[i] = 'S'; break;
                case 'X': args.encryptedtext_arg[i] = 'T'; break;
                case 'W': args.encryptedtext_arg[i] = 'U'; break;
                case 'Y': args.encryptedtext_arg[i] = 'V'; break;
                case 'Z': args.encryptedtext_arg[i] = 'W'; break;
            }
        }
        printf("N = 3 : %s\n",args.encryptedtext_arg);
    }
    cmdline_parser_free(&args);
    return EXIT_SUCCESS;
}

//Era necessário utilizar a função atoi para passar de string para integer e depois utilizar a função sprinf para pasar de inteiro para string
//em que faziamos o len da palavra dada len(args.encryptedtex_arg) e para a primeira letra era N e para a segunda N+1.
//já não tinha tempo para fazer as alterações por isso deixo aqui em comentário, mesmo sabendo que isto não vai ser contabilizado. Obrigado!